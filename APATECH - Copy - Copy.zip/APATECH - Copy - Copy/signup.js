document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('signup-form');
  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const confirmInput = document.getElementById('confirmPassword');
  const createBtn = document.getElementById('create-btn');
  const toast = document.getElementById('toast');

  const nameErr = document.getElementById('name-error');
  const emailErr = document.getElementById('email-error');
  const passwordErr = document.getElementById('password-error');
  const confirmErr = document.getElementById('confirm-error');

  const passwordStrength = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;

  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  let toastTimer = null;
  function showToast(message, type = 'success') {
    clearTimeout(toastTimer);
    toast.textContent = message;
    toast.className = `toast show ${type === 'success' ? 'success' : 'error'}`;
    toastTimer = setTimeout(() => {
      toast.className = 'toast';
    }, 3000);
  }

  const touched = { name: false, email: false, password: false, confirm: false };
  let formSubmitted = false;

  function setError(input, errElem, message, show = true) {
    errElem.textContent = show ? (message || '') : '';
    input.classList.toggle('invalid', show && Boolean(message));
  }

  function validate() {
    let valid = true;

    const nameMsg = nameInput.value.trim().length === 0 ? 'Please enter your name.' : '';
    const emailMsg = !isValidEmail(emailInput.value) ? 'Please enter a valid email.' : '';
    const passwordMsg = !passwordStrength.test(passwordInput.value) ? 'Password must be 8+ chars and include upper, lower, number & symbol.' : '';
    const confirmMsg = (confirmInput.value !== passwordInput.value || confirmInput.value.length < 8) ? 'Passwords do not match.' : '';

    if (nameMsg) valid = false;
    if (emailMsg) valid = false;
    if (passwordMsg) valid = false;
    if (confirmMsg) valid = false;

    setError(nameInput, nameErr, nameMsg, touched.name || formSubmitted);
    setError(emailInput, emailErr, emailMsg, touched.email || formSubmitted);
    setError(passwordInput, passwordErr, passwordMsg, touched.password || formSubmitted);
    setError(confirmInput, confirmErr, confirmMsg, touched.confirm || formSubmitted);

    createBtn.disabled = !valid;
    return valid;
  }


  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.dataset.target);
      if (!target) return;
      const isHidden = target.type === 'password';
      target.type = isHidden ? 'text' : 'password';
      btn.textContent = isHidden ? 'Hide' : 'Show';
    });
  });

  [nameInput, emailInput, passwordInput, confirmInput].forEach(inp => {
    inp.addEventListener('blur', () => {
      touched[inp.id] = true;
      validate();
    });

    inp.addEventListener('input', () => {
     
      validate();
    });
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!validate()) {
      formSubmitted = true;
      Object.keys(touched).forEach(k => touched[k] = true);
      validate();
      return;
    }

    const payload = {
      name: nameInput.value.trim(),
      email: emailInput.value.trim().toLowerCase(),
      password: passwordInput.value
    };

    createBtn.textContent = 'Creating...';
    createBtn.disabled = true;

    try {
      const resp = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (resp.ok || resp.status === 201) {
        showToast('Account created successfully', 'success');
        setTimeout(() => window.location.href = 'Userhomefolder/userhome.html', 850);
        return;
      }

      if (resp.status === 409) {
        setError(emailInput, emailErr, 'An account with this email already exists.');
        emailInput.focus();
        createBtn.disabled = false;
        createBtn.textContent = 'Create account';
        return;
      }

      const body = await resp.json().catch(() => ({}));
      showToast(body.message || 'Signup failed. Please try again.', 'error');
      createBtn.disabled = false;
      createBtn.textContent = 'Create account';

    } catch (err) {
      if (confirm('Could not reach the server. Save account locally for demo?')) {
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        if (users.some(u => u.email === payload.email)) {
          setError(emailInput, emailErr, 'An account with this email already exists.');
          emailInput.focus();
          createBtn.disabled = false;
          createBtn.textContent = 'Create account';
          return;
        }
        users.push(payload);
        localStorage.setItem('users', JSON.stringify(users));
        showToast('Saved locally (demo).', 'success');
        setTimeout(() => window.location.href = 'Userhomefolder/userhome.html', 850);
      } else {
        showToast('Network error. Try again later.', 'error');
        createBtn.disabled = false;
        createBtn.textContent = 'Create account';
      }
    }
  });

  document.getElementById('google-btn').addEventListener('click', () => {
    showToast('Google sign up is not implemented in this demo.', 'error');
  });

  validate();
});