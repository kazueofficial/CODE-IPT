document.addEventListener('DOMContentLoaded', function(){
  const buttons = Array.from(document.querySelectorAll('.faq-question'));

  function openPanel(panel, btn){
    panel.removeAttribute('hidden');    
    panel.style.maxHeight = panel.scrollHeight + 'px';
    btn.setAttribute('aria-expanded', 'true');


    if(window.innerWidth <= 480){
      setTimeout(()=> btn.scrollIntoView({behavior: 'smooth', block: 'nearest'}), 220);
    }

    const onEnd = function(){
      panel.style.maxHeight = 'none';
      
      if(window.innerWidth <= 480){
        setTimeout(()=> panel.scrollIntoView({behavior: 'smooth', block: 'nearest'}), 60);
      }
      panel.removeEventListener('transitionend', onEnd);
    };
    panel.addEventListener('transitionend', onEnd);
  }

  function closePanel(panel, btn){
 
    if(getComputedStyle(panel).maxHeight === 'none'){
      panel.style.maxHeight = panel.scrollHeight + 'px';
      requestAnimationFrame(()=> panel.style.maxHeight = '0');
    } else {
      panel.style.maxHeight = panel.scrollHeight + 'px';
      requestAnimationFrame(()=> panel.style.maxHeight = '0');
    }

    btn.setAttribute('aria-expanded', 'false');

    const onEnd = function(){
      panel.setAttribute('hidden','');
      panel.removeEventListener('transitionend', onEnd);
      panel.style.maxHeight = '';
    };
    panel.addEventListener('transitionend', onEnd);
  }

  buttons.forEach(btn => {
    const panel = document.getElementById(btn.getAttribute('aria-controls'));

    btn.addEventListener('click', function(){
      const isOpen = btn.getAttribute('aria-expanded') === 'true';

      if(!isOpen){
        
        buttons.forEach(other => {
          if(other !== btn && other.getAttribute('aria-expanded') === 'true'){
            const otherPanel = document.getElementById(other.getAttribute('aria-controls'));
            closePanel(otherPanel, other);
          }
        });
        openPanel(panel, btn);
      } else {
        closePanel(panel, btn);
      }
    });
  });

  let resizeTimer;
  window.addEventListener('resize', function(){
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(()=>{
      buttons.forEach(btn => {
        if(btn.getAttribute('aria-expanded') === 'true'){
          const panel = document.getElementById(btn.getAttribute('aria-controls'));
          if(getComputedStyle(panel).maxHeight !== 'none'){
            panel.style.maxHeight = panel.scrollHeight + 'px';
          }
        }
      });
    }, 120);
  });



  if(buttons.length && window.innerWidth > 480) buttons[0].click();

  
  window.addEventListener('orientationchange', function(){
    setTimeout(()=>{
      buttons.forEach(btn => {
        if(btn.getAttribute('aria-expanded') === 'true'){
          const panel = document.getElementById(btn.getAttribute('aria-controls'));
          if(getComputedStyle(panel).maxHeight !== 'none') panel.style.maxHeight = panel.scrollHeight + 'px';
        }
      });
    }, 220);
  });
});